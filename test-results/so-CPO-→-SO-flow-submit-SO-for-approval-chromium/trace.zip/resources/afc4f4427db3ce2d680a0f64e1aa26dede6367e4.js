(globalThis["TURBOPACK_CHUNK_LISTS"] || (globalThis["TURBOPACK_CHUNK_LISTS"] = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: ["static/chunks/[root-of-the-server]__06.-pfn._.css","static/chunks/node_modules__pnpm_0l5-iip._.js","static/chunks/_13ez72t._.js"],
    source: "dynamic"
});
