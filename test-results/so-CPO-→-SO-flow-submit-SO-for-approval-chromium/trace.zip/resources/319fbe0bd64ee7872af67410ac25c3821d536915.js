(globalThis["TURBOPACK_CHUNK_LISTS"] || (globalThis["TURBOPACK_CHUNK_LISTS"] = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: ["static/chunks/[turbopack]_browser_dev_hmr-client_hmr-client_ts_03~1333._.js","static/chunks/03bt_next_dist_compiled_next-devtools_index_0t9xbo6.js","static/chunks/03bt_next_dist_compiled_react-dom_12sbb~c._.js","static/chunks/03bt_next_dist_compiled_react-server-dom-turbopack_0tz6q9_._.js","static/chunks/03bt_next_dist_compiled_13mke52._.js","static/chunks/03bt_next_dist_client_0yyey53._.js","static/chunks/03bt_next_dist_11dyxva._.js","static/chunks/0i4a_@swc_helpers_cjs_0hvz.20._.js"],
    source: "entry"
});
