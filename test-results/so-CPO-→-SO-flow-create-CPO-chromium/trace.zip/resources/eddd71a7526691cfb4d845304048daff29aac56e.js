(globalThis["TURBOPACK_CHUNK_LISTS"] || (globalThis["TURBOPACK_CHUNK_LISTS"] = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: ["static/chunks/_04l_rdx._.js","static/chunks/node_modules__pnpm_07rs-2p._.js"],
    source: "dynamic"
});
